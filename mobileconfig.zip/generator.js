
$(function () {
  $('#dlbutton').click(update);

});

var template = [
'<?xml version="1.0" encoding="UTF-8"?>',
'<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">',
'<plist version="1.0">',
'<dict>',
'<key>ConsentText</key>',
'<dict>',
'<key>default</key>',
'<string>请点击右上角安装按钮进行安装。</string>',
'</dict>',
' <key>PayloadContent</key>',
' <array>',
'   <dict>',
'     <key>FullScreen</key>',
'     <true/>',
'     <key>Icon</key>',
'     <data><?base64textarea?></data>',
'     <key>IsRemovable</key>',
'     <true/>',
'     <key>Label</key>',
'     <string><?App_Name?></string>',
'     <key>PayloadDescription</key>',
'     <string>Adds a Web Clip.</string>',
'     <key>PayloadDisplayName</key>',
'     <string>Web Clip (<?App_Name?>)</string>',
'     <key>PayloadIdentifier</key>',
'     <string>com.ddgter.<?App_Creator?>.<?App_Name?>.99-5464jdfgdg-99.webclip1</string>',
'     <key>PayloadOrganization</key>',
'     <string><?App_Name?></string>',
'     <key>PayloadType</key>',
'     <string>com.apple.webClip.managed</string>',
'     <key>PayloadUUID</key>',
'     <string><?hexSource?></string>',
'     <key>PayloadVersion</key>',
'     <integer>1</integer>',
'     <key>Precomposed</key>',
'     <false/>',
'     <key>URL</key>',
'     <string><?App_PassPhrase?></string>',
'   </dict>',
' </array>',
' <key>PayloadDescription</key>',
' <string><?App_Name?></string>',
' <key>PayloadDisplayName</key>',
' <string><?App_Name?></string>',
' <key>PayloadIdentifier</key>',
' <string>com.profile.config</string>',
' <key>PayloadOrganization</key>',
' <string><?App_Creator?></string>',
' <key>PayloadRemovalDisallowed</key>',
' <false/>',
' <key>PayloadType</key>',
' <string>Configuration</string>',
' <key>PayloadUUID</key>',
' <string><?hexSource2?></string>',
' <key>PayloadVersion</key>',
' <integer>1</integer>',
'</dict>',
'</plist>',
].join('\r\n');

function generateUUID() {
    var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random()*16)%16 | 0;
        d = Math.floor(d/16);
        return (c=='x' ? r : (r&0x3|0x8)).toString(16);
    });
    return uuid;
};
function generateUUID2() {
    var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random()*16)%16 | 0;
        d = Math.floor(d/16);
        return (c=='x' ? r : (r&0x3|0x8)).toString(16);
    });
    return uuid;
};
function update() {
	document.getElementById("hexSource").value = generateUUID();
	document.getElementById("hexSource2").value = generateUUID2();
	var variables = {
		'App_Name': $('#App_Name').val(),
		'base64textarea': $('#base64textarea').val(),
		'App_PassPhrase': $('#App_PassPhrase').val(),
		'App_Creator': $('#App_Creator').val(),
		'App_Removeable': $('#App_Removeable').val(),
		'hexSource': $('#hexSource').val(),
		'hexSource2': $('#hexSource2').val(),
	};
	var newXml = template.replace(/<\?(\w+)\?>/g,
	function(match, name) {
	  return variables[name];
	});
	$('#ResultXml').val(newXml);
}
$(document).ready(function(){
	document.getElementById('filePicker').addEventListener('change', handleFileSelect, false);
});
function getImgUrl(file, cbfunc){
	let img = new Image();
	let reader = new FileReader();
	let canvas = document.createElement('canvas');
	let context = canvas.getContext('2d');
	canvas.width = 114;
	canvas.height = 114;
	reader.onload = (e)=>{
		console.log(e.target.result);
		img.src = e.target.result;
	}
	img.onload = ()=>{
		context.drawImage(img,0,0,114,114);
		let res = canvas.toDataURL('image/png', 1);
		cbfunc(1, res.replace(new RegExp('data:image/png;base64,','g'), ''));
	}
	reader.readAsDataURL(file);
}
var handleFileSelect = function(evt) {
    var files = evt.target.files;
    var file = files[0];
    if (files && file) {
		getImgUrl(file, (bl, res)=>{
			document.getElementById("base64textarea").value = res;
		});
    }
};


